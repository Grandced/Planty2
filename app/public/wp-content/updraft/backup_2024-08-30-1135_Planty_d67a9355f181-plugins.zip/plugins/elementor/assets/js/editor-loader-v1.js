/*! elementor - v3.23.0 - 05-08-2024 */
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
var __webpack_exports__ = {};
/*!*******************************************************!*\
  !*** ../core/editor/loader/v1/js/editor-loader-v1.js ***!
  \*******************************************************/


window.elementor.start();
/******/ })()
;
//# sourceMappingURL=editor-loader-v1.js.map